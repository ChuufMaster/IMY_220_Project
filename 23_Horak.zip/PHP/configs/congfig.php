<?php

$host = "localhost";
$username = "u21456552";
$password = "jdqmbgai";
$database_name = "u21456552";